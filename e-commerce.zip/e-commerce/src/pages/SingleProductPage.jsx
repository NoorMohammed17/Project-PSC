import React from 'react';
import ProductDetails from '../components/ProductDetails';

const SinglePRoductPage = () => {
  return (
    <div>
      <ProductDetails/>
      
    </div>
  )
}

export default SinglePRoductPage
